import oslo_config.cfg
from oslo_utils import importutils

_compute_opts = [
    oslo_config.cfg.StrOpt('compute_api_class',
                           default='dalek.compute.nova.API',
                           help='The full class name of the '
                                'compute API class to use'),
]

oslo_config.cfg.CONF.register_opts(_compute_opts)


def API():
    compute_api_class = oslo_config.cfg.CONF.compute_api_class
    cls = importutils.import_class(compute_api_class)
    return cls()
