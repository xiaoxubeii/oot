from oslo_config import cfg
import webob.dec
import webob.exc

from dalek import context
from dalek.openstack.common import log as logging
from dalek import wsgi

auth_opts = [
    cfg.StrOpt('auth_strategy',
               default='authcontext',
               help='The strategy to use for auth: noauth or keystone.'),
    cfg.StrOpt('tenant_default_user_password',
               help='The tenant default user password.'),
    cfg.StrOpt('tenant_default_user_name',
               help='The tenant default user name.'),
    cfg.StrOpt('tenant_name',
               help='Default tenant name.'),
    cfg.StrOpt('user_name',
               help='user name of default tenant.'),
    cfg.StrOpt('user_password',
               help='user password of default tenant.'),
    cfg.StrOpt('auth_url',
               default='http://127.0.0.1:5000/v2.0/',
               help='The keystone auth url.')
]

CONF = cfg.CONF
CONF.register_opts(auth_opts)

LOG = logging.getLogger(__name__)


def _load_pipeline(loader, pipeline):
    filters = [loader.get_filter(n) for n in pipeline[:-1]]
    app = loader.get_app(pipeline[-1])
    filters.reverse()
    for filter in filters:
        app = filter(app)
    return app


def pipeline_factory(loader, global_conf, **local_conf):
    """A paste pipeline replica that keys off of auth_strategy."""
    pipeline = local_conf[CONF.auth_strategy]
    pipeline = pipeline.split()
    return _load_pipeline(loader, pipeline)


class AdaptorContext(wsgi.Middleware):
    """Make a request context from keystone headers."""

    @webob.dec.wsgify(RequestClass=wsgi.Request)
    def __call__(self, req):
        tenant_name = req.headers.get('X_TENANT_NAME')
        user_name = None
        user_password = None

        if tenant_name:
            user_name = req.headers.get('X_USER_NAME', CONF.tenant_default_user_name % tenant_name)
            user_password = req.headers.get('X_USER_PASSWORD', CONF.tenant_default_user_password)
        else:
            tenant_name = CONF.tenant_name
            user_name = CONF.user_name
            user_password = CONF.user_password

        auth_url = req.headers.get('X_AUTH_URL', CONF.auth_url)
        region_name = req.headers.get('X_REGION_NAME')
        ctx = context.RequestContext(user_name=user_name, user_password=user_password,
                                     project_name=tenant_name, auth_url=auth_url, region_name=region_name)

        req.environ['context'] = ctx
        return self.application