from dalek import test


class BaseTestCase(test.TestCase):
    def setUp(self):
        super(BaseTestCase, self).setUp()
        pass

    def test(self):
        self.assertTrue(True)
